# Biftu — 20th Birthday Website ❤️

A romantic interactive birthday website for Biftu's 20th birthday.

## GitHub Pages

1. Create a new GitHub repository, for example `biftu-birthday`.
2. Upload **index.html** and **.nojekyll** to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select **main** and **/(root)**, then click **Save**.
6. Wait a few minutes for GitHub Pages to publish the site.

Your project-site URL will normally be:
`https://YOUR-USERNAME.github.io/biftu-birthday/`

Do not rename `index.html`; GitHub Pages uses it as the entry page.
